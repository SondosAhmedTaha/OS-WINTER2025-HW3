#ifndef __REQUEST_H__

typedef struct thread_Statistics{
    int thread_id;
    int requests_count;
    int statics_count;
    int dynamic_count;
}* thread_statistics;

typedef struct request{
    int connfd;
    struct timeval arrival_time;
    struct timeval dispatch_interval;
    struct timeval pickUp_time;
    //thread statics?
}*Request;

Request createRequest(int connfd);
//destroyReq?
thread_statistics createThreadStats(int thread_id);
//destroy?
void requestHandle(int fd, Request request, thread_statistics thread_stat); //todo edit

#endif
